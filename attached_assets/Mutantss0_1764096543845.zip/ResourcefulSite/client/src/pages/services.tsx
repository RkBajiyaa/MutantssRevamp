import { Card, CardContent } from "@/components/ui/card";
import marketingImg from "@assets/generated_images/marketing_strategy_illustration.png";
import brandImg from "@assets/generated_images/brand_identity_illustration.png";
import marketImg from "@assets/generated_images/go-to-market_illustration.png";
import imcImg from "@assets/generated_images/imc_platform_illustration.png";
import mediaImg from "@assets/generated_images/media_planning_illustration.png";
import contentImg from "@assets/generated_images/content_integration_illustration.png";
import seoImg from "@assets/generated_images/seo/smm/sem_illustration.png";
import devImg from "@assets/generated_images/development_illustration.png";
import aiImg from "@assets/generated_images/ai_automation_illustration.png";

export default function Services() {
  const services = [
    {
      title: "Marketing And Communications Strategy",
      image: marketingImg,
      description:
        "Strategic planning and execution of comprehensive marketing campaigns that drive results and build brand awareness.",
    },
    {
      title: "Brand Ideology And Visual Identity Development",
      image: brandImg,
      description:
        "Creating compelling brand narratives and distinctive visual identities that resonate with your target audience.",
    },
    {
      title: "Go To Market Strategy Execution",
      image: marketImg,
      description:
        "Launch your products and services successfully with data-driven go-to-market strategies and tactical execution.",
    },
    {
      title: "IMC Platform Management",
      image: imcImg,
      description:
        "Seamless integration and management of your marketing platforms for consistent messaging across all channels.",
    },
    {
      title: "Media Planning, Buying And Execution",
      image: mediaImg,
      description:
        "Strategic media planning and buying across traditional and digital channels to maximize ROI and reach.",
    },
    {
      title: "Cross-Channel Content Integration",
      image: contentImg,
      description:
        "Unified content strategies that deliver consistent messaging and experiences across all touchpoints.",
    },
    {
      title: "SEO, SMM, SEM",
      image: seoImg,
      description:
        "Comprehensive digital marketing services including search engine optimization, social media, and paid advertising.",
    },
    {
      title: "App/Web Development",
      image: devImg,
      description:
        "Custom web and mobile application development with focus on user experience, performance, and scalability.",
    },
    {
      title: "Gen AI And Automation",
      image: aiImg,
      description:
        "Leverage cutting-edge AI and automation technologies to streamline operations and enhance customer experiences.",
    },
  ];

  return (
    <div className="w-full">
      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="text-center space-y-6 mb-16">
            <h1
              className="text-4xl md:text-5xl font-serif font-bold text-foreground"
              data-testid="text-services-heading"
            >
              OUR SERVICES
            </h1>
            <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto">
              Comprehensive digital marketing solutions designed to accelerate
              your growth and transform your brand presence.
            </p>
          </div>

          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => (
              <Card
                key={index}
                className="overflow-hidden hover-elevate active-elevate-2 transition-all"
                data-testid={`card-service-${index}`}
              >
                <div className="aspect-square overflow-hidden bg-gradient-to-br from-purple-100 to-purple-200 dark:from-purple-900 dark:to-purple-800">
                  <img
                    src={service.image}
                    alt={service.title}
                    className="w-full h-full object-cover"
                    data-testid={`img-service-${index}`}
                  />
                </div>
                <CardContent className="p-6 space-y-3">
                  <h3
                    className="text-xl font-serif font-semibold text-foreground leading-tight"
                    data-testid={`text-service-title-${index}`}
                  >
                    {service.title}
                  </h3>
                  <p className="text-base text-muted-foreground leading-relaxed">
                    {service.description}
                  </p>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
