import { Badge } from "@/components/ui/badge";
import { Check, Zap } from "lucide-react";
import bannerBg from "@assets/generated_images/about_banner_background.png";

export default function About() {
  const features = [
    { icon: Check, label: "Data Driven", color: "bg-green-100 dark:bg-green-900" },
    { icon: Zap, label: "Fast Execution", color: "bg-blue-100 dark:bg-blue-900" },
    { icon: Check, label: "ROI Focused", color: "bg-purple-100 dark:bg-purple-900" },
    { icon: Check, label: "Scalable", color: "bg-orange-100 dark:bg-orange-900" },
  ];

  return (
    <div className="w-full">
      <section
        className="relative min-h-[60vh] flex items-center justify-center bg-slate-900 dark:bg-slate-950"
        style={{
          backgroundImage: `url(${bannerBg})`,
          backgroundSize: "cover",
          backgroundPosition: "center",
        }}
      >
        <div className="absolute inset-0 bg-slate-900/80 dark:bg-slate-950/80"></div>
        <div className="relative max-w-5xl mx-auto px-6 lg:px-8 py-20 text-center">
          <h1
            className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold text-white leading-tight"
            data-testid="text-about-heading"
          >
            YOUR GROWTH PARTNER IN THE DIGITAL ERA
          </h1>
        </div>
      </section>

      <section className="py-20 bg-background">
        <div className="max-w-4xl mx-auto px-6 lg:px-8 space-y-8">
          <p
            className="text-lg md:text-xl text-foreground leading-relaxed text-center"
            data-testid="text-about-description-1"
          >
            Mutantss is a full-service digital marketing agency that combines
            creativity with strategic thinking to deliver exceptional results. We
            believe in the power of evolution—adapting, innovating, and
            transforming to stay ahead in the digital landscape.
          </p>

          <p
            className="text-lg md:text-xl text-foreground leading-relaxed text-center"
            data-testid="text-about-description-2"
          >
            Based in Jaipur, our team specializes in SEO, PPC, social media
            marketing, content creation, web development, and data-driven growth
            strategies. We don't just execute campaigns; we build partnerships
            that drive sustainable growth and measurable success for your brand.
          </p>
        </div>
      </section>

      <section className="py-20 bg-card">
        <div className="max-w-5xl mx-auto px-6 lg:px-8">
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-6">
            {features.map((feature, index) => (
              <div
                key={index}
                className={`${feature.color} rounded-full px-6 py-4 flex items-center justify-center gap-3 hover-elevate`}
                data-testid={`badge-${feature.label.toLowerCase().replace(" ", "-")}`}
              >
                <feature.icon className="w-5 h-5 text-foreground" />
                <span className="text-base font-semibold text-foreground">
                  {feature.label}
                </span>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
