# MUTANTS Digital Marketing Agency - Design Guidelines

## Design Approach
Reference-based approach drawing inspiration from modern digital agency aesthetics (Stripe's clarity + creative agency boldness). Clean, professional layout with vibrant illustration accents. Emphasis on readability and trust-building through clear hierarchy and generous whitespace.

## Typography System

**Display Headings:** Serif font (Playfair Display or Merriweather)
- Hero: 3.5rem (56px) desktop, 2.25rem (36px) mobile, font-weight 700
- Section headings: 2.5rem (40px) desktop, 1.875rem (30px) mobile, font-weight 600
- Subsection headings: 1.875rem (30px), font-weight 600

**Body Text:** Sans-serif font (Inter or Open Sans)
- Body: 1.125rem (18px), line-height 1.7, font-weight 400
- Small text: 0.875rem (14px), font-weight 400
- Button text: 1rem (16px), font-weight 600

## Layout System

**Spacing:** Use Tailwind units of 4, 6, 8, 12, 16, 20, 24
- Section padding: py-20 desktop, py-12 mobile
- Card padding: p-8 desktop, p-6 mobile
- Element spacing: gap-8 for grids, gap-6 for smaller components

**Container Widths:**
- Max-width: 1280px (max-w-7xl)
- Content sections: max-w-6xl
- Text content: max-w-4xl

## Page-Specific Layouts

### Home Page
1. **Hero Section** (full viewport height recommended)
   - Two-column layout: Left (60%) text content, Right (40%) illustration
   - Purple gradient background (light purple to deeper purple, diagonal)
   - Serif heading with tagline below
   - Primary CTA button
   
2. **Philosophy Section**
   - Single column, centered, max-w-4xl
   - Heading + subheading + 3 short paragraphs in grid (3 columns desktop, 1 mobile)

3. **Impact Quote Section**
   - Two-column: Left (50%) large quote text, Right (50%) illustration with green frame accent
   - Centered on mobile

4. **Two-Column Highlight**
   - Equal width columns (50/50)
   - Each with heading + descriptive paragraph
   - Border/card treatment for visual separation

### About Page
1. **Banner Hero**
   - Full-width dark navy background with subtle tech pattern/wireframe overlay
   - Centered large heading
   - Height: 60vh

2. **Content Section**
   - Two paragraphs, centered, max-w-3xl
   - Generous vertical spacing

3. **Feature Badges**
   - 4-column grid (2x2 mobile)
   - Rounded pill-shaped badges with icons/symbols
   - Mix of checkmarks and decorative symbols

### Services Page
1. **Header**
   - Centered heading + subtext

2. **Service Grid**
   - 3-column grid desktop, 1 column mobile
   - 9 service cards total
   - Each card: colorful illustration, service title, brief description
   - Rounded corners, subtle shadow, hover lift effect

### Contact Page
1. **Header**
   - "Let's Chat" heading
   - Contact name + phone prominently displayed

2. **Two-Column Layout**
   - Left (40%): Office address in clean typography
   - Right (60%): Contact form with fields: First Name, Last Name, Email, Comment textarea, Submit button
   - Stack on mobile

## Component Library

**Navigation Header**
- White background, thin bottom border
- Logo left, menu links right (Home, About Us, Services, Contact)
- Sticky positioning
- Height: 80px

**Buttons**
- Primary: Dark background, white text, rounded-lg, px-8 py-4, subtle hover state
- Submit: Matching primary style

**Cards (Service)**
- White background, rounded-xl, p-8
- Colorful top illustration area
- Title + description below
- Shadow: subtle on default, elevated on hover

**Form Inputs**
- Border: 1px solid light gray
- Rounded-md, p-4
- Focus state: border highlight
- Labels above inputs

**Feature Badges**
- Rounded-full, px-6 py-3
- Icon/symbol + text
- Varied background colors (green, blue, purple tints)

## Images

**Illustrations Needed:**
1. **Home Hero:** Large creative/abstract digital marketing illustration (charts, devices, creative elements) - Right side of hero
2. **Impact Quote:** Abstract design/content illustration with green rectangular frame styling - Right side
3. **Service Cards (9 total):** Colorful, distinct illustrations for each service:
   - Marketing strategy (megaphone/charts)
   - Brand identity (palette/design tools)
   - Go-to-market (rocket/launch)
   - IMC platform (connected devices)
   - Media planning (calendar/media icons)
   - Content integration (puzzle pieces)
   - SEO/SMM/SEM (search/social icons)
   - Development (code/devices)
   - AI/Automation (robot/circuits)

4. **About Banner:** Wireframe human head or tech pattern background - Full width, subtle overlay

**Image Treatment:** All illustrations should be vibrant, modern, flat design style with purple/blue/green color harmony. Use placeholder image services or describe for custom creation.

## Responsive Behavior
- Navigation: Hamburger menu below 768px
- Service grid: 3 cols → 2 cols → 1 col
- Two-column sections: Stack vertically on mobile
- Hero: Illustration moves below text on mobile
- Typography scales down by 25-30% on mobile