import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import heroImage from "@assets/generated_images/hero_marketing_illustration.png";
import impactImage from "@assets/generated_images/impact_quote_illustration.png";

export default function Home() {
  return (
    <div className="w-full">
      <section className="relative min-h-[90vh] flex items-center bg-gradient-to-br from-purple-100 via-purple-200 to-purple-300 dark:from-purple-950 dark:via-purple-900 dark:to-purple-800">
        <div className="max-w-7xl mx-auto px-6 lg:px-8 py-20">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-8">
              <h1
                className="text-4xl md:text-5xl lg:text-6xl font-serif font-bold text-foreground leading-tight"
                data-testid="text-hero-heading"
              >
                MUTANTSS – WHERE DIGITAL MARKETING EVOLVES
              </h1>
              <p className="text-xl md:text-2xl text-muted-foreground font-semibold">
                Innovate. Dominate. Accelerate.
              </p>
              <div>
                <Button
                  size="lg"
                  className="text-lg px-8 py-6 rounded-lg"
                  data-testid="button-book-call"
                >
                  Book a Strategy Call
                </Button>
              </div>
            </div>
            <div className="flex justify-center">
              <img
                src={heroImage}
                alt="Digital Marketing Illustration"
                className="w-full max-w-lg rounded-xl"
                data-testid="img-hero"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-background">
        <div className="max-w-6xl mx-auto px-6 lg:px-8">
          <div className="text-center space-y-6 mb-16">
            <h2
              className="text-3xl md:text-4xl font-serif font-semibold text-foreground"
              data-testid="text-philosophy-heading"
            >
              Our Philosophy
            </h2>
            <p className="text-xl text-muted-foreground font-medium">
              Welcome to Team Mutantss!
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="text-center space-y-4">
              <p className="text-lg text-foreground leading-relaxed">
                In the ever-changing digital landscape, adaptation isn't
                optional—it's survival. We don't just keep up with trends; we
                evolve beyond them.
              </p>
            </div>
            <div className="text-center space-y-4">
              <p className="text-lg text-foreground leading-relaxed">
                Our approach merges creativity with cutting-edge technology,
                transforming challenges into opportunities and ideas into
                measurable results.
              </p>
            </div>
            <div className="text-center space-y-4">
              <p className="text-lg text-foreground leading-relaxed">
                Like mutants, we continuously adapt, innovate, and push
                boundaries to help your brand thrive in the digital ecosystem.
              </p>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-card">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-12 items-center">
            <div className="space-y-6">
              <p
                className="text-2xl md:text-3xl lg:text-4xl font-serif leading-relaxed text-foreground"
                data-testid="text-impact-quote"
              >
                We craft digital experiences that merge design, content, and
                performance—turning ideas into outcomes.
              </p>
            </div>
            <div className="flex justify-center">
              <div className="relative">
                <div className="absolute inset-0 border-4 border-green-500 rounded-xl transform translate-x-4 translate-y-4"></div>
                <img
                  src={impactImage}
                  alt="Creative Design Illustration"
                  className="relative w-full max-w-lg rounded-xl"
                  data-testid="img-impact"
                />
              </div>
            </div>
          </div>
        </div>
      </section>

      <section className="py-20 bg-background">
        <div className="max-w-7xl mx-auto px-6 lg:px-8">
          <div className="grid lg:grid-cols-2 gap-8">
            <Card className="p-8 space-y-4 hover-elevate">
              <h3 className="text-2xl md:text-3xl font-serif font-semibold text-foreground">
                Exploring Creative Depths
              </h3>
              <p className="text-lg text-muted-foreground leading-relaxed">
                We dive deep into research, design thinking, and storytelling to
                uncover insights that drive meaningful connections. Our creative
                process is rooted in understanding your audience and crafting
                narratives that resonate.
              </p>
            </Card>

            <Card className="p-8 space-y-4 hover-elevate">
              <h3 className="text-2xl md:text-3xl font-serif font-semibold text-foreground">
                Building Brands for the Long Run
              </h3>
              <p className="text-lg text-muted-foreground leading-relaxed">
                Success isn't a one-time achievement—it's a continuous journey.
                We build sustainable brand ecosystems through strategic planning,
                consistent optimization, and data-driven decision making.
              </p>
            </Card>
          </div>
        </div>
      </section>
    </div>
  );
}
