# Mutantss Digital Marketing Agency

## Overview

Mutantss is a full-service digital marketing agency website built as a modern, professional marketing platform. The application showcases the agency's services, philosophy, and provides contact functionality for potential clients. It's designed with a clean, creative aesthetic featuring purple gradients and vibrant illustrations to reflect the agency's innovative approach to digital marketing.

The application is a full-stack TypeScript project using React for the frontend with a Node.js/Express backend, featuring a contact form with database persistence and a professionally designed marketing site.

## User Preferences

Preferred communication style: Simple, everyday language.

## System Architecture

### Frontend Architecture

**Framework**: React 18 with TypeScript using Vite as the build tool and development server.

**Routing**: Wouter for client-side routing, providing a lightweight alternative to React Router for basic navigation between pages (Home, About, Services, Contact).

**UI Component System**: Shadcn/ui component library with Radix UI primitives. This provides accessible, customizable components with Tailwind CSS styling. The design system uses a "new-york" style variant with custom theming based on HSL color variables.

**State Management**: TanStack Query (React Query) for server state management, handling API requests and caching. No global client state management needed as the application is primarily content-focused.

**Styling Approach**: Tailwind CSS with custom configuration including:
- Custom color system using CSS variables for theme consistency
- Typography system with serif fonts (Playfair Display/Merriweather) for headings and sans-serif (Inter/Open Sans) for body text
- Responsive design with mobile-first approach
- Custom spacing scale and container widths following design guidelines

**Form Handling**: React Hook Form with Zod schema validation for type-safe form validation, used specifically in the contact form.

### Backend Architecture

**Server Framework**: Express.js running on Node.js with TypeScript.

**Development vs Production**: Split server configuration:
- `index-dev.ts`: Development mode with Vite middleware for HMR (Hot Module Replacement)
- `index-prod.ts`: Production mode serving pre-built static assets

**API Design**: RESTful endpoints under `/api` prefix:
- `POST /api/contact`: Submit contact form data
- `GET /api/contact/submissions`: Retrieve all contact submissions (admin endpoint)

**Request Processing**: Express middleware for JSON parsing with raw body preservation for potential webhook integrations.

### Data Storage Solutions

**Database**: PostgreSQL with Drizzle ORM for type-safe database operations.

**ORM Configuration**: Drizzle configured with:
- Schema location: `shared/schema.ts`
- Migration output: `./migrations`
- PostgreSQL dialect using Neon serverless driver for connection pooling

**Schema Design**:
- `users` table: Basic user authentication structure with username/password (minimal implementation)
- `contact_submissions` table: Stores contact form submissions with firstName, lastName, email, message, and timestamp

**Fallback Storage**: In-memory storage implementation (`MemStorage` class) for development/testing without database dependency. This provides the same interface as database storage for seamless switching.

**Data Validation**: Zod schemas derived from Drizzle table schemas using `drizzle-zod` for runtime validation matching database constraints.

### Design System Implementation

**Typography Hierarchy**:
- Display headings: Serif fonts at 56px (desktop) / 36px (mobile)
- Section headings: 40px (desktop) / 30px (mobile)
- Body text: 18px with 1.7 line-height for readability

**Layout System**:
- Maximum container width: 1280px (max-w-7xl)
- Consistent spacing using Tailwind units (4, 6, 8, 12, 16, 20, 24)
- Section padding: py-20 desktop, py-12 mobile

**Color Palette**:
- Primary: Purple gradient (#271 75% variants) for brand identity
- Background: Neutral grays with subtle variations for depth
- Accent colors for CTAs and interactive elements

**Page Structures**:
- Hero sections with gradient backgrounds and illustrations
- Two-column layouts for content presentation
- Card-based service listings
- Responsive grid systems

### Build and Deployment Architecture

**Build Process**:
1. Frontend: Vite builds React application to `dist/public`
2. Backend: ESBuild bundles server code to `dist/index.js`
3. Assets: Static files served from built public directory

**Module System**: ES Modules throughout (type: "module" in package.json)

**TypeScript Configuration**:
- Path aliases for clean imports (@/, @shared/, @assets/)
- Strict mode enabled for type safety
- ESNext module resolution for modern bundler compatibility

**Development Workflow**:
- Hot module replacement via Vite in development
- Replit-specific plugins for enhanced development experience
- Automatic browser refresh on file changes